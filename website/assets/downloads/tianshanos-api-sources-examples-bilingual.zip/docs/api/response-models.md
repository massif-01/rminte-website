# 常用返回模型

下面描述 `data` 内的字段；外层HTTP状态与code的处理见[通用规则](conventions.md)。字段随设备状态、功能初始化和调用者角色变化；没有读到字段时保留“未知”，不要自动补成0或false。

## temperature

| 字段 | 读法 |
| --- | --- |
| temperature_c / temperature_01c | 摄氏度 / 十分之一摄氏度，是同一个量 |
| valid | 当前值是否可用；false时不作为正常温度参与判断 |
| source / active_source / preferred_source | 本次来源 / 实际来源 / 首选来源；具体接口命名不同 |
| timestamp_ms / last_update_ms | 本次设备启动后的时间，不是Unix时间 |
| stale / age_ms | 数据是否陈旧 / 已经过的毫秒；null可能表示从未更新 |
| partial_stale / valid_count / stale_count | 多变量绑定中部分来源失效；不能只看平均数 |

系统会限制有效温度范围；温度输入本身可来自本地传感器、算力遥测、变量或手动测试。读到手动值不证明物理温度就是该值。

## fan

`fan.status` 指定id返回一个风扇对象，省略id返回 `{fans:[…],temperature,temp_valid,temp_source}`。

| 字段 | 类型、单位与读法 |
| --- | --- |
| id / mode | 风扇编号 / off、manual、auto、curve |
| duty_valid / duty | 输出有效性 / 实际已知占空比%；未知时duty为null |
| target_duty | 控制器目标输出%，可能与实际输出不同 |
| rpm | 转速，转/分钟；要结合测速能力和故障状态 |
| enabled / running / fault | 启用 / 运行 / 故障；未知运行状态可以是null |
| temperature | 此风扇控制相关温度，°C |
| control_temperature / guard_temperature / predicted_temperature | 控制、保护、预测使用的温度，°C |
| slope_c_per_min | 温度变化率，°C/分钟 |
| auto_state / guard_active / temp_stale | 自动控制阶段、保护是否生效、温度是否陈旧 |
| controller_gain / cooling_response | 控制器诊断量；不将其当转速或温度 |

写配置的applied/persisted分别表达应用和保存；请求50%不能当作硬件已经产生50%有效输出。

## power

`power.status` 聚合电压、电源芯片、保护和统计；细读使用 `.voltage/.chip/.protection.status`。

| 字段 | 单位或意义 |
| --- | --- |
| voltage_v / current_a / power_w | V / A / W |
| voltage_mv | mV，数值不能直接与V比较 |
| valid / crc_valid | 数据有效、通信校验有效；电源芯片数据同时检查 |
| timestamp_ms | 启动后毫秒 |
| state / countdown_remaining_sec | 保护阶段 / 保护倒计时秒数 |
| initialized / running | 保护是否完成初始化 / 正在运行 |

`device.power.status` 是另一种电源轨模型，rails项采用voltage_mv/current_ma/power_mw，汇总为total_power_mw。算力监控的power同样可能采用mW；以字段页标注为准。

## config-result

对象保存、配置来源切换等返回一组状态。不是所有接口每次都返回全部字段。

| 字段 | 意义 |
| --- | --- |
| active_version | 当前配置版本；下一次修改使用本次的新值 |
| source | 当前活动配置来源 |
| loaded / configured / enabled / paused | 已加载 / 已有配置 / 已启用 / 已暂停，是不同状态 |
| saved / uncertain | 是否完成保存 / 保存结果是否不确定 |
| load_error / internal_error | 活动配置或内部备份的错误 |
| sd_available / internal_exists / internal_valid | SD可用 / 内部备份存在 / 内部备份有效 |
| comparison_known / backup_matches | 是否能比较 / 备份是否相同；比较未知时不能当作相同 |
| awaiting_sd_choice | 需要选择是否采用SD配置 |
| internal_saved_at | 内部备份的保存时间信息 |
| collection / id / dependency | 操作关联的集合、对象、依赖位置 |
| impact | 删除或替换会影响的引用与运行记录 |

导入预览的package_digest、credential_generation是正式应用的校验条件，不是可复用的全局授权。restart_required=false也不能替代loaded/enabled/运行任务状态。

## variable

变量含name/type或value_type/value，可能附source_id、persistent、readonly、flags、last_change_ms、last_update_ms、age_ms、stale。variables.list通过include_value选择是否返回值，include_meta选择元数据。不要用“value字段没有返回”推导变量值为null。

## certificate

`cert.status` 分开报告has_private_key、has_certificate、has_ca_chain，以及设备证书信息和独立HTTPS诊断服务状态。证书有效性可能依赖time_ready；尚未建立可信时间时不能把“未判定”当作有效。

设备证书、独立HTTPS诊断服务实际加载的身份、诊断客户端是否信任它是三个问题。安装后读取服务状态；需要重载时按维护流程处理。业务API仍通过HTTP访问，其Bearer角色与mTLS诊断角色分开。

## color

RGB分量为0–255。`led.fill` 等直接颜色参数接受支持的字符串、r/g/b对象或0xRRGGBB对应的十进制整数；JSON不能直接写十六进制数字。`led.color.hsv` 使用h=0–359度、s/v=0–255，不是百分比。

颜色校正的返回是配置对象：enabled；white_point含enabled/red_scale/green_scale/blue_scale；gamma含enabled/gamma；brightness、saturation含enabled/factor。比例范围0–2，gamma范围0.1–4。修改使用相同子对象结构；普通设备brightness的0–255与校正factor不是一种单位。

## ota

URL或SD方式启动后读取ota.progress；它是设备全局状态，没有每个会话独立的操作回执。APP进度含state/percent/total_size/received_size/message；WWW进度含state/percent/total/received/message/running。APP的pending_reboot表示等待重启，WWW完成时state=completed且running=false；100%不单独证明设备已运行新版本。

分区信息含label/address/size、可启动状态与可用的version/project；can_rollback表示当前是否具备回滚条件。取消接口的aborted是本次取消调用反馈，随后继续确认进度与现状。

直传使用独立响应。若HTTP409返回status=partial、error=recovery_cache_failed、flash_written=true，表示Flash已写入但SD恢复缓存未完整保存。此时先核对分区和恢复文件，不能当作未写入而自动重试。

## network

以太网的interface_present表示接口是否存在，link_up表示物理链路状态；config_error/config_error_name说明配置应用错误。已连线不等于已成功获得或应用IP配置。

DHCP的running是实际运行状态，eth的want_running是期望状态。restore_error/apply_error/resume_error分别用于定位配置恢复、应用及断线后恢复服务的问题；0表示该步骤未报告错误。先结合接口与链路状态，再判断服务是否应当运行。
