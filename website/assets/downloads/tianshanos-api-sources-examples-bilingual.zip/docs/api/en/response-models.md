# Common response models

These fields are inside data. Handle HTTP status and code as described in [Common rules](conventions.md). Fields vary with device state, initialization, and role. Preserve unknown when a field is missing; do not fill it with0 orfalse.

## temperature

| Field | Interpretation |
| --- | --- |
| temperature_c / temperature_01c | Celsius / tenths of a degree; the same measurement |
| valid | Whether the value is usable; false must not be treated as normal temperature |
| source / active_source / preferred_source | This reading's source / actual source / preferred source, depending on the API |
| timestamp_ms / last_update_ms | Milliseconds since device start, not Unix time |
| stale / age_ms | Staleness / age in milliseconds; null may mean never updated |
| partial_stale / valid_count / stale_count | Partial failure of a multi-variable binding; inspect more than its average |

The implementation bounds valid temperature values. Inputs can come from local sensors, compute telemetry, variables, or manual tests. A manual value does not establish the physical temperature.

## fan

fan.status with id returns one fan; without id it returns fans plus temperature/temp_valid/temp_source.

| Field | Type, unit, or meaning |
| --- | --- |
| id / mode | Fan number / off, manual, auto, curve |
| duty_valid / duty | Output validity / known actual duty in percent; unknown duty is null |
| target_duty | Target output percentage; can differ from actual duty |
| rpm | Revolutions per minute; interpret with tachometer capability and faults |
| enabled / running / fault | Enabled / running / fault; unknown running can be null |
| temperature | Relevant control temperature, Celsius |
| control_temperature / guard_temperature / predicted_temperature | Control, protection, and predicted temperature, Celsius |
| slope_c_per_min | Temperature slope in Celsius per minute |
| auto_state / guard_active / temp_stale | Automatic stage, active guard, stale temperature |
| controller_gain / cooling_response | Diagnostic values, not RPM or temperatures |

applied and persisted distinguish application from storage. Requesting50% does not establish a valid physical50% output.

## power

power.status combines voltage, chip measurements, protection, and statistics. Use the specific voltage/chip/protection.status APIs for details.

| Field | Unit or meaning |
| --- | --- |
| voltage_v / current_a / power_w | V / A / W |
| voltage_mv | mV; convert before comparing to V |
| valid / crc_valid | Data validity / communication integrity; check both for chip measurements |
| timestamp_ms | Milliseconds since start |
| state / countdown_remaining_sec | Protection stage / countdown seconds |
| initialized / running | Initialization complete / protection running |

device.power.status instead reports rails with voltage_mv/current_ma/power_mw and total_power_mw. Compute telemetry can also use mW; follow each field's unit.

## config-result

Configuration writes and source selection return a set of state flags; not every response contains all of them.

| Field | Meaning |
| --- | --- |
| active_version | Current configuration version; use the new returned value for the next write |
| source | Active configuration source |
| loaded / configured / enabled / paused | Loaded / configured / enabled / paused; separate states |
| saved / uncertain | Storage completed / outcome uncertain |
| load_error / internal_error | Active configuration or internal-backup error |
| sd_available / internal_exists / internal_valid | SD available / internal backup exists / backup valid |
| comparison_known / backup_matches | Comparison possible / matching backup; unknown is not a match |
| awaiting_sd_choice | An SD selection is required |
| internal_saved_at | Internal backup save-time information |
| collection / id / dependency | Collection, object, or dependency location |
| impact | References and runs affected by deletion/replacement |

Preview package_digest and credential_generation are apply preconditions, not reusable global authorization. restart_required:false does not replace loaded/enabled or runtime checks.

## variable

Variables include name, type/value_type, and possibly value, source_id, persistent, readonly, flags, last_change_ms, last_update_ms, age_ms, and stale. variables.list uses include_value for values and include_meta for metadata. A missing value field is not a null value.

## certificate

cert.status separately reports has_private_key, has_certificate, has_ca_chain, certificate information, and the separate HTTPS diagnostic-service status. Certificate validity may depend on time_ready; undetermined is not valid.

An installed identity, the identity loaded by the separate HTTPS diagnostic service, and diagnostic-client trust are separate checks. Inspect service status after installation. Business APIs remain on HTTP; their Bearer roles are separate from mTLS certificate roles.

## color

RGB components are0-255. Direct color APIs accept supported strings, r/g/b objects, or the decimal integer equivalent of 0xRRGGBB; JSON does not allow hexadecimal numeric literals. led.color.hsv uses h=0-359 degrees and s/v=0-255, not percentages.

Color correction is an object: enabled; white_point with enabled/red_scale/green_scale/blue_scale; gamma with enabled/gamma; brightness/saturation with enabled/factor. Scales range0-2; gamma ranges0.1-4. Send nested objects when modifying them. Device brightness0-255 and a correction factor are different units.

## ota

After a URL or SD start, read ota.progress. It reports device-wide state, without a private per-login receipt. APP progress has state/percent/total_size/received_size/message; WWW progress has state/percent/total/received/message/running. APP pending_reboot means a restart is needed; WWW completion uses state=completed and running=false. 100 percent alone does not prove the new version is running.

Partitions report label/address/size, bootability, and available version/project. can_rollback reports current rollback availability. aborted acknowledges the cancel call; continue checking progress and actual state.

Binary uploads use a separate response. HTTP409 with status=partial, error=recovery_cache_failed, and flash_written=true means Flash was written but the SD recovery cache was not fully saved. Inspect partitions and recovery files before retrying.

## network

Ethernet interface_present reports interface existence; link_up reports the physical link. config_error/config_error_name report configuration-application errors. A connected cable does not establish a successful IP configuration.

DHCP running is actual state; Ethernet want_running is requested state. restore_error/apply_error/resume_error distinguish configuration restore, application, and service resumption failures. Zero means that step reported no error. Check interface and link state before deciding whether the service should run.
