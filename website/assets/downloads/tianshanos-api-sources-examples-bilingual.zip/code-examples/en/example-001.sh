export TS_BASE='http://10.10.99.97'
