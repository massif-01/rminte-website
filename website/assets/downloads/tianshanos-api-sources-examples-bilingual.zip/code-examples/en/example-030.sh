python3 read_status.py --base 'http://10.10.99.97' \
  --user admin
