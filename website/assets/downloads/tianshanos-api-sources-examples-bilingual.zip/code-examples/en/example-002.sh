curl --connect-timeout 5 --max-time 15 \
  "$TS_BASE/api/v1/system/info"
