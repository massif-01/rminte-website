umask 077
curl --connect-timeout 5 --max-time 15 \
  -H 'Content-Type: application/json' \
  --data-binary @login.json \
  "$TS_BASE/api/v1/auth/login" > login-response.json
