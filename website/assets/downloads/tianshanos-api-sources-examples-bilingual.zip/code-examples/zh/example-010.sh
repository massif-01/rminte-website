curl -H "Authorization: Bearer $TS_TOKEN" \
  "$TS_BASE/api/v1/temp/read"
curl -H "Authorization: Bearer $TS_TOKEN" \
  "$TS_BASE/api/v1/fan/status"
curl -H "Authorization: Bearer $TS_TOKEN" \
  "$TS_BASE/api/v1/power/status"
curl -H "Authorization: Bearer $TS_TOKEN" \
  "$TS_BASE/api/v1/device/status?device=agx"
