# TianshanOS 0.6.4 API 文档

中文入口：docs/api/README.md。English: docs/api/en/README.md。

本包包含中英文完整Markdown底稿、277个接口的结构化JSON/CSV数据、只读接入示例和两份PDF。Markdown与data目录可用于制作API文档网站。

默认使用HTTP80和普通WebSocket；默认账户admin/root，初始密码均为rm01。已改密时使用当前密码。

PDF位于pdf目录。各PDF包含可点击目录、接口索引、书签及示例附件。代码框使用可选择文字，右上角回形针可保存原始代码；不支持附件的阅读器可使用code-examples目录中的同名文件。manifest.json记录文件摘要。
